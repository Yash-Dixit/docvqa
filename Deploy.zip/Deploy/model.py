#Importing libraries
import glob
import json
import re
import collections
import random
import os
import time
import warnings
import fasttext
import datetime
import pickle
import pandas as pd
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib.image as mpimg
from PIL import Image
from tqdm import tqdm
from similarity.normalized_levenshtein import NormalizedLevenshtein
warnings.filterwarnings('ignore')

def preprocess_qa(w):
  '''
    The function 'preprocess_qa' preprocesses both the questions as well as answers.
  '''
  # creating a space between a word and the punctuation following it
  # eg: "he is a boy." => "he is a boy ."
  # Reference:- https://stackoverflow.com/questions/3645931/python-padding-punctuation-with-white-spaces-keeping-punctuation
  w = re.sub('([!"#$%&()*+.,-/:;=?@[\]<>?^_`{|}~])', r' \1 ', w)
  w = re.sub('\s{2,}', ' ', w)

  # replacing everything with space except (a-z, A-Z, ".", "?", "!", ",")
  w = re.sub('(?<=[A-Za-z])(?=[0-9])|(?<=[0-9])(?=[A-Za-z])',' ', w)

  w = ' '.join(e.lower() for e in w.split())

  w = w.strip()

  # adding a start and an end token to the sentence
  # so that the model know when to start and stop predicting.
  w = '<start> ' + w + ' <end>'
  return w

def preprocess_ocr(w):
  '''
    The function 'preprocess_ocr' preprocesses ocrs.
  '''
  with open(w, 'r') as f:
    annotations = json.load(f)
  w = ''
  for i in range(len(annotations['recognitionResults'][0]['lines'])):
    w+= ' '+annotations['recognitionResults'][0]['lines'][i]['text']
  w = w.split(' Source: ', 1)[0]
  w = preprocess_qa(w)
  return w

def load_image(image_path):
    img = tf.io.read_file(image_path)
    img = tf.image.decode_jpeg(img, channels=3)
    img = tf.image.resize(img, (299, 299))
    img = tf.keras.applications.inception_v3.preprocess_input(img)
    return img, image_path

class Encoder(tf.keras.Model):
  '''
    Encoder model -- That takes a input sequence and returns encoder output sequence.
  '''
  def __init__(self, vocab_size, embedding_dim, enc_units, batch_sz, inp_embed_mat):
    super(Encoder, self).__init__()
    self.batch_sz = batch_sz
    self.enc_units = enc_units
    self.embedding = tf.keras.layers.Embedding(vocab_size, 
                                               embedding_dim,
                                               weights=[inp_embed_mat],
                                               trainable=False)
    self.ocr_gru = tf.keras.layers.GRU(self.enc_units,
                                   return_sequences=True,
                                   return_state=True,
                                   recurrent_initializer='glorot_uniform')
    self.question_gru = tf.keras.layers.GRU(self.enc_units,
                                   return_sequences=True,
                                   return_state=True,
                                   recurrent_initializer='glorot_uniform')
    self.fc = tf.keras.layers.Dense(embedding_dim)

  def call(self, image, ocr, question, hidden):
    '''
      This function takes a sequence input of question, ocr and image and the initial state of the question encoding.
      Pass the input sequences of question and ocr input to the Embedding layer, Pass the embedding layer ouput to gru layers
      returns -- All encoder_outputs, last time steps hidden states.
    '''
    
    #==================== Image Encoding ====================
    #Squashing the output shape of the InceptionV3 model to (batch_size,64,embedding_dim) 
    image = self.fc(image)
    #features shape after passing through the Dense Layer == (batch_size, 64, embedding_dim)
    image = tf.nn.relu(image)

    #==================== Question Encoding ====================
    # question shape after passing through embedding == (batch_size, input_length(41), embedding_dim)
    question = self.embedding(question)
    # output shape == (batch_size, input_length(41), gru_size(enc_units))
    # state shape == (batch_size, gru_size(enc_units))
    question_output, question_state = self.question_gru(question, initial_state = hidden)

    #==================== OCR Encoding ====================
    # question shape after passing through embedding == (batch_size, input_length(41), embedding_dim)
    ocr = self.embedding(ocr)
    # output shape == (batch_size, input_length(220), gru_size(enc_units))
    # state shape == (batch_size, gru_size(enc_units))
    ocr_output, ocr_state = self.ocr_gru(ocr, initial_state = question_state)
    
    return image, ocr_output, ocr_state, question_output, question_state

  def initialize_hidden_state(self):
    return tf.zeros((self.batch_sz, self.enc_units))


class Image_Attention(tf.keras.Model):
  '''
    Class that calculates Image attention score based on the scoring_function.
  '''
  def __init__(self, units):
    super(Image_Attention, self).__init__()
    self.W1 = tf.keras.layers.Dense(units)
    self.W2 = tf.keras.layers.Dense(units)
    self.V = tf.keras.layers.Dense(1)

  def call(self, features, hidden_i):
    '''
      Attention mechanism takes two inputs current step -- image_hidden_state and all the image_encoder_output.
      * Based on the scoring function we will find the score or similarity between image_hidden_state and image_encoder_output.
        Multiply the score function with your encoder_outputs to get the context vector.
        Function returns context vector and attention weights(softmax - scores)
    '''
    # features(CNN_encoder output) shape == (batch_size, 64, embedding_dim)

    # hidden shape == (batch_size, hidden_size)
    # hidden_with_time_axis shape == (batch_size, 1, hidden_size)
    hidden_with_time_axis_q = tf.expand_dims(hidden_i, 1)

    # attention_hidden_layer shape == (batch_size, 64, units)
    attention_hidden_layer = (tf.nn.relu(self.W1(hidden_with_time_axis_q) +
                                         self.W2(features)))

    # score shape == (batch_size, 64, 1)
    # This gives you an unnormalized score for each image feature.
    score = self.V(attention_hidden_layer)

    # attention_weights shape == (batch_size, 64, 1)
    attention_weights = tf.nn.softmax(score, axis=1)

    # context_vector shape after sum == (batch_size, hidden_size)
    context_vector = attention_weights * features
    context_vector = tf.reduce_sum(context_vector, axis=1)

    return context_vector, attention_weights


class OCR_Attention(tf.keras.layers.Layer):
  '''
    Class that calculates OCR attention score based on the scoring_function.
  '''
  def __init__(self, units):
    super(OCR_Attention, self).__init__()
    self.W1 = tf.keras.layers.Dense(units)
    self.W2 = tf.keras.layers.Dense(units)
    self.V = tf.keras.layers.Dense(1)

  def call(self, query_o, values):
    '''
      Attention mechanism takes two inputs current step -- Concatenated question and ocr hidden_states and all the ocr_encoder_output.
      * Based on the scoring function we will find the score or similarity between hidden_states and ocr_encoder_output.
        Multiply the score function with your ocr_encoder_output to get the context vector.
        Function returns context vector and attention weights(softmax - scores)
    '''
    # query hidden state shape == (batch_size, ocr hidden size)
    # query_with_time_axis shape == (batch_size, 1, ocr hidden size)
    # values shape == (batch_size, max_len, ocr hidden size)
    # we are doing this to broadcast addition along the time axis to calculate the score
    query_with_time_axis_o = tf.expand_dims(query_o, 1)

    # score shape == (batch_size, max_length(220), 1)
    # we get 1 at the last axis because we are applying score to self.V
    # the shape of the tensor before applying self.V is (batch_size, max_length(220), units)
    score = self.V(tf.nn.relu(self.W1(query_with_time_axis_o) + 
                              self.W2(values)))

    # attention_weights shape == (batch_size, max_length(220), 1)
    attention_weights = tf.nn.softmax(score, axis=1)

    # context_vector shape after sum == (batch_size, ocr_hidden_size)
    context_vector = attention_weights * values
    context_vector = tf.reduce_sum(context_vector, axis=1)

    return context_vector, attention_weights


class Question_Attention(tf.keras.layers.Layer):
  '''
    Class that calculates Question attention score based on the scoring_function.
  '''
  def __init__(self, units):
    super(Question_Attention, self).__init__()
    self.W1 = tf.keras.layers.Dense(units)
    self.W2 = tf.keras.layers.Dense(units)
    self.V = tf.keras.layers.Dense(1)

  def call(self, query_q, values):
    '''
      Attention mechanism takes two inputs current step -- Concatenated question and ocr hidden_states and all the question_encoder_output.
      * Based on the scoring function we will find the score or similarity between hidden_states and question_encoder_output.
        Multiply the score function with your question_encoder_output to get the context vector.
        Function returns context vector and attention weights(softmax - scores)
    '''
    # query hidden state shape == (batch_size, question hidden size)
    # query_with_time_axis shape == (batch_size, 1, question hidden size)
    # values shape == (batch_size, max_len, question hidden size)
    # we are doing this to broadcast addition along the time axis to calculate the score
    query_with_time_axis_q = tf.expand_dims(query_q, 1)

    # score shape == (batch_size, max_length(41), 1)
    # we get 1 at the last axis because we are applying score to self.V
    # the shape of the tensor before applying self.V is (batch_size, max_length(41), units)
    score = self.V(tf.nn.relu(self.W1(query_with_time_axis_q) + 
                              self.W2(values)))

    # attention_weights shape == (batch_size, max_length(41), 1)
    attention_weights = tf.nn.softmax(score, axis=1)

    # context_vector shape after sum == (batch_size, question_hidden_size)
    context_vector = attention_weights * values
    context_vector = tf.reduce_sum(context_vector, axis=1)

    return context_vector, attention_weights


class Decoder(tf.keras.Model):
  '''
      Decoder model -- That takes a encoder outputs and hidden states and returns the target output sequence.
  '''
  def __init__(self, vocab_size, embedding_dim, dec_units, batch_sz, targ_embed_mat):
    super(Decoder, self).__init__()
    
    #Initializing the variables
    self.batch_sz = batch_sz
    self.dec_units = dec_units
    
    # Initializing the layers
    self.embedding = tf.keras.layers.Embedding(vocab_size, 
                                               embedding_dim,
                                               weights=[targ_embed_mat],
                                               trainable=False)
    self.gru = tf.keras.layers.GRU(self.dec_units,
                                   return_sequences=True,
                                   return_state=True,
                                   recurrent_initializer='glorot_uniform',
                                   dropout=0.1)
    self.fc = tf.keras.layers.Dense(vocab_size,
                                    activation='sigmoid', 
                                    kernel_regularizer='l1')

    # Initializing the attention layers
    self.question_attention = Question_Attention(self.dec_units)
    self.ocr_attention = OCR_Attention(self.dec_units)
    self.image_attention = Image_Attention(self.dec_units)

  def call(self, x, hidden_q, hidden_o, hidden_i, enc_output_i, enc_output_o, enc_output_q):
    '''
        This function takes "input to decoder(x)", "question, ocr and image encoder outputs", 
        "encoder hidden states (hidden_q, hidden_o, hidden_i)" and "decoder hidden state which is input 
        from the hidden_q while predicting" for carrying out the operations of scoring function and attention 
        weigths for every input in the input_to_decoder(x).
    '''

    #=*=*=*=*=*=*=*=*=*=*= Concatenating the hidden states for the attentions =*=*=*=*=*=*=*=*=*=*=


    #Concatenating the ocr and question hidden states for ocr and question attentions.
    hidden_qo = tf.concat([hidden_o,hidden_q],axis=-1)


    #=*=*=*=*=*=*=*=*=*=*= Calculating the context vectors and attention weights =*=*=*=*=*=*=*=*=*=*=


    #==================== Question Attention ====================
    # defining question attention as a separate model
    # enc_output shape == (batch_size, input_length(41), hidden_size)
    context_vector_q, attention_weights_q = self.question_attention(hidden_qo, 
                                                                    enc_output_q)

    #==================== OCR Attention ====================
    # defining question attention as a separate model
    # enc_output shape == (batch_size, input_length(220), hidden_size)
    context_vector_o, attention_weights_o = self.ocr_attention(hidden_qo, 
                                                               enc_output_o)

    #==================== Image Attention ====================
    # defining image attention as a separate model
    context_vector_i, attention_weights_i = self.image_attention(enc_output_i,
                                                                 hidden_i)


    #=*=*=*=*=*=*=*=*=*=*= Concatenating the Context Vectors =*=*=*=*=*=*=*=*=*=*=
    

    #==================== Concat OCR Context Vector ====================
    # Here x represents Decoder Input
    # x shape after passing through embedding == (batch_size, 1, embedding_dim)
    x = self.embedding(x)
    # x shape after concatenation == (batch_size, 1, embedding_dim  + ocr_hidden_size)
    x = tf.concat([tf.expand_dims(context_vector_o, 1), x], axis=-1)
    
    #==================== Concat Question Context Vector ====================
    # x shape after concatenation == (batch_size, 1, embedding_dim + ocr_hidden_size + question_hidden_size)
    x = tf.concat([tf.expand_dims(context_vector_q, 1), x], axis=-1)
    
    #==================== Concat Image Context Vector ====================
    # x shape after concatenation == (batch_size, 1, embedding_dim + ocr_hidden_size + question_hidden_size + image_hidden_size)
    x = tf.concat([tf.expand_dims(context_vector_i, 1), x], axis=-1)


    #=*=*=*=*=*=*=*=*=*=*= Decoding Answer =*=*=*=*=*=*=*=*=*=*=


    # passing the concatenated vector to the GRU
    output, state = self.gru(x, initial_state = hidden_q)

    # output shape == (batch_size * 1, hidden_size)
    output = tf.reshape(output, (-1, output.shape[2]))

    # output shape == (batch_size, vocab)
    x = self.fc(output)

    return x, state, attention_weights_q, attention_weights_o, attention_weights_i

  def reset_state(self, batch_size):
    return tf.zeros((batch_size, self.dec_units))


def evaluate(question, ocr, image, encoder, decoder, image_features_extract_model, max_length_inp_q, max_length_inp_o, max_length_targ, attention_features_shape, units, text):
  '''
    The function 'evaluate' takes 2 main parameters:
      question = preproccessed Question tokens with <start> and <end> present in them.
      ocr = preproccessed OCR tokens with <start> and <end> present in them.
      image = the image features from the InceptionV3 model.

    It returns 
      result=the predicted answer is in a sentence format for the QUESTION and ANSWER attention plot, 
      img_result=the predicted answer is in the form of list for the IMAGE and ANSWER attention plot, 
      sentence=passing the same sentence which has been passed as a parameter,
      attention_plot=these are the attention weights for the QUESTION and ANSWER attention plot, 
      image_attention_plot=these are the attention weights for the IMAGE and ANSWER attention plot . 
  '''
  question_attention_plot = np.zeros((max_length_targ, max_length_inp_q))
  image_attention_plot = np.zeros((max_length_targ, attention_features_shape))
  result = ''
  img_result = []
  hidden = tf.zeros((1, units))

  
  #===== Question Input Preprocess =====
  question = preprocess_qa(question)
  inputs_q = [text.word_index[i] for i in question.split(' ')]
  inputs_q = tf.keras.preprocessing.sequence.pad_sequences([inputs_q],
                                                           maxlen=max_length_inp_q,
                                                           padding='post')
  inputs_q = tf.convert_to_tensor(inputs_q)


  #===== OCR Input Process =====
  temp_ocr_result = preprocess_ocr(ocr)
  if len(temp_ocr_result.split())<221:
    ocr = temp_ocr_result
  else:
    ocr_words = temp_ocr_result.split()
    temp_final_ocr = ' '.join(ocr_words[:219])
    if '<end>' not in temp_final_ocr:
      temp_final_ocr = temp_final_ocr + ' <end>'
    ocr = temp_final_ocr

  inputs_o = ''
  if len(ocr.split())==2:
    inputs_o = [text.word_index[i] for i in ['<start>','<end>']]
    inputs_o = tf.keras.preprocessing.sequence.pad_sequences([inputs_o],
                                                            maxlen=max_length_inp_o,
                                                            padding='post')
    inputs_o = tf.convert_to_tensor(inputs_o)

  else:
    inputs_o = [text.word_index[i] for i in ocr.split(' ')]
    inputs_o = tf.keras.preprocessing.sequence.pad_sequences([inputs_o],
                                                            maxlen=max_length_inp_o,
                                                            padding='post')
    inputs_o = tf.convert_to_tensor(inputs_o)


  #=====Image Input Preprocess=====
  temp_input = tf.expand_dims(load_image(image)[0], 0)
  img_tensor_val = image_features_extract_model(temp_input)
  img_tensor_val = tf.reshape(img_tensor_val, (img_tensor_val.shape[0], -1, img_tensor_val.shape[3]))

  
  #=====Encoder Phase=====
  enc_out_i, enc_out_o, enc_hidden_o, enc_out_q, enc_hidden_q = encoder(img_tensor_val,
                                                                        inputs_o,
                                                                        inputs_q,
                                                                        hidden)

  dec_hidden_q = enc_hidden_q
  dec_hidden_o = enc_hidden_o
  
  dec_input = tf.expand_dims([text.word_index['<start>']], 0)

  #=====Decoder Phase=====
  img_hidden = decoder.reset_state(batch_size=1)
  
  for t in range(max_length_targ):
    predictions, dec_hidden, question_attention_weights, _, image_attention_weights = decoder(dec_input,
                                                                                              dec_hidden_q,
                                                                                              dec_hidden_o,
                                                                                              img_hidden,
                                                                                              enc_out_i,
                                                                                              enc_out_o,
                                                                                              enc_out_q)

    # storing the attention weights to plot later on
    question_attention_weights = tf.reshape(question_attention_weights, (-1, ))
    question_attention_plot[t] = question_attention_weights.numpy()
    image_attention_plot[t] = tf.reshape(image_attention_weights, (-1, )).numpy()

    predicted_id = tf.argmax(predictions[0]).numpy()

    if predicted_id==0:
      result += text.index_word[predicted_id+1] + ' '
      img_result.append(text.index_word[predicted_id+1] + ' ')
    else:
      result += text.index_word[predicted_id] + ' '
      img_result.append(text.index_word[predicted_id] + ' ')
      if text.index_word[predicted_id] == '<end>':
        return result, img_result, question, ocr, question_attention_plot, image_attention_plot

    # the predicted ID is fed back into the model
    dec_input = tf.expand_dims([predicted_id], 0)
    
    dec_hidden_q = dec_hidden
    dec_hidden_o = dec_hidden

  image_attention_plot = image_attention_plot[:len(result), :]
  return result, img_result, question, ocr, question_attention_plot, image_attention_plot


# function for plotting the question attention weights
def plot_attention(attention, sentence, predicted_sentence):
  fig = plt.figure(figsize=(10,10))
  ax = fig.add_subplot(1, 1, 1)
  ax.matshow(attention, cmap='viridis')

  fontdict = {'fontsize': 14}

  ax.set_xticklabels([''] + sentence, fontdict=fontdict, rotation=90)
  ax.set_yticklabels([''] + predicted_sentence, fontdict=fontdict)

  ax.xaxis.set_major_locator(ticker.MultipleLocator(1))
  ax.yaxis.set_major_locator(ticker.MultipleLocator(1))

  plt.show()


# function for plotting the image attention weights
def image_plot_attention(image, result, attention_plot):
    temp_image = np.array(Image.open(image))

    fig = plt.figure(figsize=(10, 10))

    len_result = len(result)
    for l in range(len_result):
        temp_att = np.resize(attention_plot[l], (8, 8))
        ax = fig.add_subplot(len_result, len_result, l+1)
        ax.set_title(result[l])
        img = ax.imshow(temp_image)
        ax.imshow(temp_att, cmap='gray', alpha=0.6, extent=img.get_extent())

    plt.tight_layout()
    plt.show()


def predict_answer(question, ocr, image_input,  encoder, decoder, image_features_extract_model, max_length_inp_q, max_length_inp_o, max_length_targ, attention_features_shape, units, text, graph=True, anls=False):
  '''
    The function predict_answer takes in the useful parameters required for predicting the outputs.
    
    Based on the value of the variable 'anls', if it is true then it returns the attention weights
    along with the prediction for calculating the scores.

    Also if the variable 'graph' is set to True then it outputs all the attention weights or else
    it returns only the predicted answers
  '''
  result, img_result, question, ocr, attention_plot, image_attention_plot = evaluate(question,
                                                                                     ocr,
                                                                                     image_input, 
                                                                                     encoder, 
                                                                                     decoder, 
                                                                                     image_features_extract_model, 
                                                                                     max_length_inp_q,
                                                                                     max_length_inp_o,
                                                                                     max_length_targ, 
                                                                                     attention_features_shape, 
                                                                                     units, 
                                                                                     text)

  result = result.replace(' <end>','')
  #print('{}\n'.format(result))

  if anls:
    if graph:
      attention_plot = attention_plot[:len(result.split(' ')), :len(question.split(' '))]
      plot_attention(attention_plot, question.split(' '), result.split(' '))
      image_plot_attention(image_input,img_result,image_attention_plot)
      return result
    else:
      return result
  else:
    if graph:
      attention_plot = attention_plot[:len(result.split(' ')), :len(question.split(' '))]
      plot_attention(attention_plot, question.split(' '), result.split(' '))
      image_plot_attention(image_input,img_result,image_attention_plot)
    else:
      return result



