from flask import Flask, jsonify, request
#Importing libraries
import glob
import json
import re
import collections
import random
import os
import time
import warnings
import fasttext
import datetime
import pickle
import pandas as pd
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib.image as mpimg
import model as s
from PIL import Image
from tqdm import tqdm
from similarity.normalized_levenshtein import NormalizedLevenshtein
warnings.filterwarnings('ignore')
import flask
app = Flask(__name__)

#Initializing global variables
number = 0
image = []
ocr = []
question = []

@app.route('/index')
def index():
	return flask.render_template('index.html')

@app.route('/index1', methods=['POST'])
def index1():
	global number 
	number = int(request.form['nm'])
	return flask.render_template('temp1/index.html')

@app.route('/predict', methods=['POST'])
def predict():
	global image
	global number
	global ocr
	global question
	to_predict_list = request.form.to_dict()
	image.append(to_predict_list['image'])
	ocr.append(to_predict_list['ocr'])
	question.append(to_predict_list['question'])
	number = number-1
	if number!=0:
		return flask.render_template('temp1/index.html')
	else:
		start_time = time.time()
		max_length_inp_q = 41
		max_length_inp_o = 220
		max_length_targ = 39
		batch_size=1
		attention_features_shape = 64
		embedding_dim=300
		units=128
		_,_,_,_, text, embedding_matrix = pickle.load(open('train.pkl', 'rb'))
		vocab_size=len(text.word_index)+1
		encoder = s.Encoder(vocab_size,
				embedding_dim,
				units,
				batch_size,
				embedding_matrix)
		decoder = s.Decoder(vocab_size,
				embedding_dim, 
				units, 
				batch_size,
				embedding_matrix)
		#Initializing the optimizer
		optimizer = tf.keras.optimizers.Adam()
		#Initializing the model checkpoint directory
		checkpoint_dir = './training_checkpoints'
		checkpoint_prefix = os.path.join(checkpoint_dir, "ckpt")
		checkpoint = tf.train.Checkpoint(optimizer=optimizer,
                                 encoder=encoder,
                                 decoder=decoder)
		checkpoint.restore(checkpoint_dir+'/ckpt-3').expect_partial()
		image_model = tf.keras.applications.InceptionV3(include_top=False,
                                                weights='imagenet')
		new_input = image_model.input
		hidden_layer = image_model.layers[-1].output
		image_features_extract_model = tf.keras.Model(new_input, hidden_layer)
		result = []
		for idx in range(len(question)):
			result.append(s.predict_answer(question[idx],ocr[idx],image[idx], encoder, decoder, image_features_extract_model, max_length_inp_q, max_length_inp_o, max_length_targ, attention_features_shape, units, text, False))
		return jsonify({'prediction/s': list(np.array(result)), 'time': time.time() - start_time})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
